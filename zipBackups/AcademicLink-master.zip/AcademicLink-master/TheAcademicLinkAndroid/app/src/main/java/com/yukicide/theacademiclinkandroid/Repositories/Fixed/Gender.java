package com.yukicide.theacademiclinkandroid.Repositories.Fixed;

public enum Gender {
    MALE, FEMALE;
}
