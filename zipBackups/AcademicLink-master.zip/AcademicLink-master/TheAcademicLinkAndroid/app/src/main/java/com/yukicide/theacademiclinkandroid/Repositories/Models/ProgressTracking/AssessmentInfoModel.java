package com.yukicide.theacademiclinkandroid.Repositories.Models.ProgressTracking;

public class AssessmentInfoModel {
    String id, name;
    int weight;
}
