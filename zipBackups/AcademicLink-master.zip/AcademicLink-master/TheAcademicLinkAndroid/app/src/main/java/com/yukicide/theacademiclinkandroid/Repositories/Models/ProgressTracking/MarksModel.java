package com.yukicide.theacademiclinkandroid.Repositories.Models.ProgressTracking;

class MarksModel {
    AssessmentInfoModel assessmentInfo;
    Double mark;
}
