package com.yukicide.theacademiclinkandroid.Repositories.Fixed;

public class CollectionName {
    public static final String SUBJECTS = "subjects";
    public static final String NOTIFICATIONS = "notifications";
    public static final String NOTES = "notes";
    public static String CLASS = "class";
    public static String USERS = "users";
}
