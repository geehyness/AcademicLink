package com.yukicide.theacademiclinkandroid.Repositories.Fixed;

public enum NotificationRank {
    URGENT, GENERAL;
}
