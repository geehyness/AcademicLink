package com.yukicide.theacademiclinkandroid.Repositories.Fixed;

public enum UserType {
    STUDENT, TEACHER, PARENT, ADMIN;
}
