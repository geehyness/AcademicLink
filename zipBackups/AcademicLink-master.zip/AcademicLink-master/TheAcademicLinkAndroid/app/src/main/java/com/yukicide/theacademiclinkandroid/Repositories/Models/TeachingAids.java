package com.yukicide.theacademiclinkandroid.Repositories.Models;

public class TeachingAids {
}
