package com.yukicide.theacademiclinkandroid.Repositories.Fixed;

public class StringExtras {
    public static final String NOTIFICATION = "NOTIFICATION";
    public static final String PROFILE_USER = "PROFILE_USER";
    public static final String CLASS_ID = "CLASS_ID";
    public static final String ASSIGN_SUBJECT = "ASSIGN_SUBJECT";
    public static final String SUBJECT = "SUBJECT";
    public static String CURRENT_USER = "CURRENT_USER";
    public static String CLASS = "CLASS";
}
