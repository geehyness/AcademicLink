package com.yukicide.theacademiclinkandroid.AppUI.adminUI.studentCRUD;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.yukicide.theacademiclinkandroid.R;

public class AddBatchStudentsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_batch_students);
    }
}
