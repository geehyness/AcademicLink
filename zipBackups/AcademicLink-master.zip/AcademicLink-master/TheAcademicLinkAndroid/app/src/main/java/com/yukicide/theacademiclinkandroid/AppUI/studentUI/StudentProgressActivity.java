package com.yukicide.theacademiclinkandroid.AppUI.studentUI;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.yukicide.theacademiclinkandroid.R;

public class StudentProgressActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_progress);
    }
}